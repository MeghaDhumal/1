#ifndef USREX_h
#define USREX_h

#include"User.h"
#include<conio.h>

class UserException:public exception
{
	private:
			char ErrorMsg[50];
	public:
		UserException(const char *);
	    char const *what() const;
};
#endif