

Skip to content
Using Gmail with screen readers
Enable desktop notifications for Gmail.
   OK  No thanks

Conversations
me
cppexception
 
Attachment

pragaticpp.zip
10:40 AM
0.76 GB (5%) of 15 GB used
Manage
Terms · Privacy · Program Policies
Last account activity: 24 minutes ago
Details

#include"User.h"
#include"UserException.h"
#include<conio.h>
int main(void)
{
	User us;
	cin >>us;
	cout << us;
	try
	{
		us.validate();
	}
	catch (UserException e)
	{
		cout<<e.what();
	}
	_getch();
	return 0;
}
