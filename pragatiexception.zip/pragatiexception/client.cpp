#include"student.h"
#include<fstream>
#include<conio.h>
#include"exception.h"
#include<iostream>
using namespace std;
class fileoperation
{
public :
	static void WriteRecord()
	{
		fstream fs;
		student s;
		char wish;
		fs.open("student.dat", ios::out | ios::binary);
		do
		{
			s.accept();
			fs.write((char*)&s, 1 * sizeof(student));
			cout << "\n do u want to add more records";
			cin >> wish;
		} while (wish == 'Y' || wish == 'y');
		fs.close();
	}

	static void ReadRecord()
	{
		fstream fs;
		student s;
		fs.open("student.dat", ios::in | ios::binary);
		while (fs.read((char*)&s, 1 * sizeof(student)))
		{
			s.display();
			cout << "current position of get pointer is" << fs.tellg();
		}
		fs.close();

	}
	/*static bool searchRecord(int rno)
	{
		fstream fs;
		student s;
		fs.open("student.dat", ios::in | ios::binary);
		while (fs.read((char*)&s, 1 * sizeof(student)))
		{
			if (s.getrollno() == rno)
			{
				s.display();
				
				fs.close();
				return true;
			}
			
		}
		fs.close();
		return false;
	}*/
	static bool searchRecord(const char * name)
	{
		fstream fs;
		student s;
		fs.open("student.dat", ios::in | ios::binary);
		while (fs.read((char*)&s, 1 * sizeof(student)))
		{
			if (strcmp(s.getname(),name) == 0)
			{
				s.display();

				fs.close();
				return true;
			}

		}
		fs.close();
		return false;
	}
	static bool searchRandom(int rno)
	{
		fstream fs;
		student s;
		fs.open("student.dat", ios::in | ios::binary);
		cout << "\n the current position of get pointer is" << fs.tellg();
		fs.seekg((rno - 1) * sizeof(student), ios::beg);
		fs.read((char*)&s, 1 * sizeof(student));
		s.display();
		return true;
	}
};

int main()
{
	cout << "\n file operations";
	char wish1;
	int result;
	try
	{
		do
		{
			int choice;
			cout << "\n 1. write records \n 2. read records \n 3. search records  \n 4. search random records \n 5. exit";
			cout << "\n enter your choice";
			cin >> choice;

			switch (choice)
			{
			case 1: fileoperation::WriteRecord();
				break;
			case 2: fileoperation::ReadRecord();
				break;
			case 3:
				int rno;
				char name[15];
				cout << "\n enter the name no to be search";
				cin >> name;
				result = fileoperation::searchRecord(name);
				if (result)
				{
					cout << "record found";


				}
				else
				{
					cout << "not found";

				}
				break;
			case 4:
				cout << "\n enter the roll no to be search";
				cin >> rno;
				fileoperation::searchRandom(rno);
				break;

			case 5: exit(0);
			}
			cout << "do u want to perform fileoperations";
			cin >> wish1;


		} while (wish1 == 'Y' || wish1 == 'y');
	}
	catch (studentException ex)
	{
		cout << ex.what();
	}
	_getch();
	return 0;

}