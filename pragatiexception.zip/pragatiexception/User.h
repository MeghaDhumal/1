#ifndef USR_h
#define USR_h

#include<iostream>
using namespace std;
#include<stdio.h>
class User
{
	private:
			char username[10];
			char password[20];
	public:
			User();
			User(const char *,const char *);
			const char * validate();
			//friend ostream& operator<<(ostream&,User&);
			//friend istream& operator>>(istream&, User&);
};
#endif

