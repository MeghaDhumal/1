#include"User.h"
#include"UserException.h"

UserException::UserException(const char *errmsg)
{
	strcpy(this->ErrorMsg,errmsg);
}
char const* UserException::what() const
{
	return this->ErrorMsg;
}