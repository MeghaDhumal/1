#include<iostream>
//#include<conio.h>
#include"Factorial.h"
void factorial::fact()
{
    f=1;
    cout<<"\nEnter a Number:";
    cin>>n;
    for(int i=1;i<=n;i++)
        f=f*i;
}
 
void factorial::display()
{
    cout<<"\nFactorial of "<<n<<" is "<<f;
}