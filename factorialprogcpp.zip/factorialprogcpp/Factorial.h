#include<iostream>
#include<conio.h>
using namespace std;
 
class factorial{
    int f, n;
    public:
    void fact();
    void display();
};