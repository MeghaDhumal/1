
#include<iostream>
#include<conio.h>
#include"Factorial.h"

int main()
{
   // clrscr();
    factorial ob;
    ob.fact();
    ob.display();
    _getch();
	return 0;

}