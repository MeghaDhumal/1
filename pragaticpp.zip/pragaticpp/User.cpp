#include "User.h"
#include"UserException.h"
#include<string.h>
User::User()
{
	strcpy(this->username,"unknown");
	strcpy(this->password, "unknownpwd");
}

User::User(const char *un, const char *pwd)
{
	strcpy(this->username, un);
	strcpy(this->password, pwd);
}
const char * User::validate()
{
	if (strlen(this->password) <= 8)
	{
		UserException ex("\nPlease enter the passward upto eight characters");
		throw ex;
		
	}
}
ostream & operator<<(ostream & out, User &u)
{
	out << u.username;
	out <<"\n"<< u.password;
	return out;
}
istream & operator>>(istream & in, User &u)
{
	cout << "\nEnter the User name:";
	in >> u.username;
	cout << "\nEnter Password :";
	in>> u.password;
	return in;
}
