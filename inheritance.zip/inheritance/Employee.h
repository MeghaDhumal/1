#include<iostream>
#include"Person.h"
using namespace std;
class Employee:public Person
{
protected:
	 int empid;
	
	
public:
	Employee();
	Employee(const char*, const char*, double, int);
	void accept();
	void display();

};