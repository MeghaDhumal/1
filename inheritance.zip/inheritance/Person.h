#include<iostream>
using namespace std;
class Person
{
	protected:
		char name[10];
		char city[10];
		double salary;

public:
	Person();
	Person(const char*,const char*,double);
	void accept();
	void display();

};