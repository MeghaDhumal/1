#include"Person.h"
using namespace std;

Person::Person()
{
	strcpy(this->name,"unknown");
	strcpy(this->city,"city");
	this->salary = 0.0;
}

Person::Person(const char* name, const char* city, double salary)
{
	strcpy(this->name, "unknown");
	strcpy(this->city, "city");
	this->salary = salary;
}
void Person::accept()
{
	cout << "\n enter the name::";
	cin >> this->name;
	cout << "\n enter the city::";
	cin >> this->city;

}
void Person::display()
{
	cout << "\n The details are-------";
	cout << "\n name::" << this->name;
	cout << "\nSalary::" << this->salary;

}




