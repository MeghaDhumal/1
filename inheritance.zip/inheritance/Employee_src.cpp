#include<iostream>
#include"Employee.h"
#include"Person.h"
using namespace std;

 Employee::Employee()
 {
	 this->empid = 0;
	
 }

 Employee::Employee(const char*name , const char*city, double salary,int empid):Person(name,city,salary)
 {
	this->empid=empid;
 }
 void Employee::accept()
 {
	 cout << "\n enter the empid::";
	 cin >> this->empid;


 }
 void Employee::display()
 {
	 cout << "\n The details are-------";
	 Person::display();
	 cout << "\n empid::" << this->empid;
	
 }
