#include"Employee.h"
#include<conio.h>

int main()
{
	Employee e;

	e.accept();
	e.display();
	Employee e1("Suresh", 12, 12, 12, 45.00);

	e1.display();


	_getch();
	return 0;
}